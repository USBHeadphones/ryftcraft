RYFTCRAFT: UNIVERSAL EDITION
============================

Ryftcraft: Universal Edition 1.19.2, a fan remake (not affiliated with Mojang)
that runs in your web browser, from one file. No installer, no account, no
internet needed once you have it.

Fan remake. Not affiliated with Mojang or Microsoft.


WHAT'S IN HERE
--------------

  README.txt                     this file
  Ryftcraft Universal Edition/   the game; keep everything in this folder together
      Ryftcraft Universal Edition.html   the game itself: open this to play
      worlds/                    your worlds are saved here
      resourcepacks/             resource packs and music packs (.zip) go here
      shaders/                   shader packs (.zip) go here
      THIRD_PARTY_NOTICES.txt    licences for the parts the game is built with

The game saves straight into this folder, so your worlds go wherever the folder
goes. To back them up, copy the "worlds" folder somewhere safe.


STARTING THE GAME
-----------------

Open "Ryftcraft Universal Edition.html" in Chrome or Edge. The browser asks
to open the game's folder once each time you start: press Start, then
click "Allow" (or "Edit files"). Browsers don't remember that permission
for a page opened from your own computer, so it asks every time.


WHAT YOU NEED
-------------

  - Google Chrome or Microsoft Edge (on a Chromebook, the built-in Chrome).
    Firefox and Safari can't open the game's folder, where your worlds and
    packs are kept: use Chrome or Edge.
  - A resource pack compatible with version 1.19.2 (a .zip). The game comes
    without world textures, sounds or music of its own, and asks for a
    pack the first time.
  - A keyboard and a mouse or touchpad. A mouse makes building much easier.
  - About 1 GB of free memory.


PLAYING ON A CHROMEBOOK
-----------------------

1. Download the zip.
   It lands in your Downloads folder.

2. Copy the game out of the zip.
   Open the Files app and go to Downloads. Double-click the zip: ChromeOS opens
   it like a USB drive. Click the "Ryftcraft Universal Edition" folder, press
   Ctrl + C, go back to Downloads (or anywhere in "My files"), and press Ctrl + V.

   This step matters: a zip can't be written to, so the game couldn't save
   your worlds if you played it from inside the zip.

   When it's copied, you can eject the zip (the eject arrow next to its name
   in the Files app sidebar).

3. Start the game.
   Open the "Ryftcraft Universal Edition" folder you just copied and
   double-click "Ryftcraft Universal Edition.html". It opens in Chrome.
   (If it opens in something else: right-click it, choose "Open with", then
   "Chrome".)

4. Choose the game's folder (first time only).
   The game asks where to keep your worlds. Click "Choose Folder", pick the
   "Ryftcraft Universal Edition" folder (the one the .html file is in), and
   click "Select". Chrome then asks for permission to edit the files in that
   folder - click "Edit files" (or "Allow").

   Chrome asks this once each time you start the game; it doesn't remember
   it for a page opened from your computer.

5. Add a resource pack (first time only).
   The game comes without world textures, sounds or music, so it asks for a
   resource pack. Click "Choose Pack File..." and pick the pack's .zip (a pack
   compatible with version 1.19.2). Or put the .zip in the "resourcepacks"
   folder and click "Done". The game starts once it has a pack with textures
   in it. That first pack becomes the game's Default (kept in the hidden
   resourcepacks/.defaults folder); packs you add later go on top of it. To
   change it: Options, Resource Packs, Default Pack... (the old one goes back
   among your packs). Packs made for OptiFine's connected textures work;
   Options, Video Settings, Connected Textures turns them off.

6. Play!
   Click Singleplayer, then Create New World.

Next time, just double-click the .html file again. If Chrome asks for the
folder again, click anywhere or press any key and allow it.

Tip: to start the game quickly, open it once, then drag the tab's address
(the "file:///..." at the top) onto your bookmarks bar.


CHROMEBOOK KEYS
---------------

Chromebooks have no F-keys, but the top row of keys works as F1 to F10 when you
hold the Search key (the magnifying glass, or the Launcher key):

  Search + 1st top key (Back)       = F1   hide the screen overlay
  Search + 2nd top key (Forward)    = F2   take a screenshot
  Search + 3rd top key (Refresh)    = F3   show coordinates and info
  Search + 5th top key (Windows)    = F5   change the camera view
  Full screen key (rectangle)       =      full screen

To use the top row as F-keys all the time: Settings > Device > Keyboard and
inputs > turn on "Treat top-row keys as function keys".

On the touchpad:
  click                = break blocks / attack
  two-finger click     = place blocks / use items
  E                    = inventory
  Esc                  = pause menu (it also gives you your mouse pointer back)

You can change any key in Options > Controls > Key Binds.


MAKING IT RUN SMOOTHLY
----------------------

Most Chromebooks play well with a few changes in Options > Video Settings:

  - Render Distance: 6 to 8 chunks (lower is faster)
  - Graphics: Fast
  - Clouds: OFF
  - Smooth Lighting: OFF (on slower Chromebooks)

Shader packs look great but need a strong machine. If the game feels slow,
turn shaders off in Options > Shader Packs.

Close other tabs while playing: the game likes having the memory to itself.


PLAYING WITH FRIENDS (LAN)
--------------------------

  Your name:       Options > Profile... (3 to 16 letters, numbers or _).

  Host a world:    in a world, press Esc > Open to LAN. Name the LAN world,
                   pick the game mode, cheats, how many can play, and whether
                   it shows on your network, then click Start LAN World. The
                   chat shows its 6-digit code.
                   Or start fresh: Multiplayer > Create LAN World makes a new
                   world and opens it to LAN as soon as it loads.

  Join a world:    Multiplayer lists the LAN worlds on your network; pick one
                   and type the host's code. From another network, use
                   Direct Connection and the code.

  Hosting and joining need the internet for a moment to connect.


RESOURCE PACKS, MUSIC AND SHADERS
---------------------------------

  Resource packs:  put the pack's .zip in "resourcepacks", or drag it onto the
                   game window. Turn it on in Options > Resource Packs.

  Music:           the game has no music of its own: a resource pack with music
                   in it brings it, or a music pack. To make your own music
                   pack, go to Options > Resource Packs >
                   Make Music Pack..., pick your own music files (mp3, ogg, m4a
                   or wav), choose where each one plays, and click Create Pack.
                   "Save a Copy..." gives you the pack's zip to share.

  Shader packs:    put the shader pack's .zip in "shaders", then choose it in
                   Options > Shader Packs. Packs made for OptiFine or Iris for
                   1.19 work best.


IF SOMETHING GOES WRONG
-----------------------

  The game says it "needs WebGL2" or shows a black screen:
      In Chrome, open Settings > System and turn on "Use graphics acceleration
      when available", then restart Chrome.

  It doesn't ask for a folder, or the folder can't be chosen:
      Some school or work Chromebooks block this. Click "Play Without Saving"
      to play anyway - but nothing is kept once you close the tab, so build
      something small!

  Some things are magenta-and-black squares, or there is no sound:
      Your resource pack doesn't have those textures or sounds in it. Add a
      fuller pack in Options > Resource Packs, or put one above it in the
      list.

  The page is blank or very slow to start:
      Give it a few seconds. If it never starts, close other tabs and try
      again.

  I want to start over with the folder:
      Options > Game Folder > Stop Using the Folder. Your worlds stay in the
      folder; the game just stops reading it until you choose one again.

Have fun!
